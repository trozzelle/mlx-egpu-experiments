# Native R9700 Producer — Implementation Plan

## Source grounding

- `CONTEXT.md` — canonical terms: Path C, Native R9700 producer, Native consumer backend, DwarfStar reference, KV interchange format.
- `docs/ARCHITECTURE.md` — Path C hybrid staged boundary; native producer before native consumer backend; DwarfStar as reference only.
- `docs/DESIGN.md` — Native R9700 producer contract, Runtime-discovery gate, DwarfStar reference contract, validation/error gates.
- `docs/ROADMAP.md` — Phase C0 through C3 sequencing and promotion gates.
- `docs/adr/0001-kv-interchange-format-boundary.md` — KV interchange format remains the boundary for Path A and first Path C producer.
- `docs/adr/0002-producer-owns-kv-truth.md` — producer owns KV truth; consumer holds compatibility state.
- `docs/adr/0003-hybrid-staged-path-c.md` — Path C starts as native producer, not backend rewrite or DwarfStar fork.
- `docs/pinned-upstream-interfaces.md` — mlx-lm KV ABI and `generate_step` S-1 prompt-cache contract; TinyGPU/tinygrad AMD facts for comparison.
- `docs/egpu-prefill-offload-reference.md` — Path C runtime-spike rationale and DwarfStar source facts.
- `docs/path-a-validation-results.md` — passing Phase 0 parity baseline.

## Goal

Build a tinygrad-free **Native R9700 producer** that runs prefill work on the AMD Radeon AI PRO R9700, emits the validated KV interchange format, and passes the same token-exact producer-swap gate against mlx-lm. Only after producer parity and serving integration are proven should the project decide whether to build a direct native mlx-lm/oMLX backend.

## Non-goals

- Do not start with an mlx-lm/oMLX backend rewrite.
- Do not fork DwarfStar or adopt its model scope, server/API boundary, compressed KV/session format, or Strix Halo ROCm target as this project's architecture.
- Do not build a generic ROCm platform or general GGUF runner.
- Do not silently downgrade producer acceptance to semantic equivalence; `P == R` token-for-token is the gate.
- Do not expose network/TCP transport before a focused security/transport review.

## Current status

| Phase | State | Current reader guidance |
|---|---|---|
| C0 | C0A host-device transfer pass; kernel proof next | Final selected state is still `blocked` until kernel proof and C0 decision rerun complete. The local R9700 is visible through TinyGPU.app/IOKit PCI as `APLRemotePCIDevice '1002:7551'`, `PCIIface`, `pcibus usb4`, `arch gfx1201`; the stale libusb-only probe checked the wrong path. C0B now records a tinygrad-free native AMDev/SDMA transfer pass: RemoteCmd discovery, BAR/MMIO, MAP_SYSMEM_FD page lists, fixed gfx12 page-table writes, MMHUB VMID0/TLB setup, SDMA0 7.0.1 queue0 submission, BAR2 doorbell, fence polling, and CPU byte comparison. |
| C1 | Dependency-blocked | Do not start native producer parity, runtime shells, model kernels, or C1 command discovery until C0 selects a runtime substrate or records an actionable split production/reference plan. |
| C2 | Dependency-blocked | Wait for C1 token-exact parity before serving integration work. |
| C3 | Dependency-blocked | Wait for C2 serving/performance evidence before any native backend decision or prototype. |

Required next action: implement and review the minimal macOS kernel launch proof on the existing TinyGPU.app/APLRemotePCIDevice/PCIIface native path. The prerequisite transfer log `logs/c0b-native-amdev-sdma-transfer.log` now shows `host_device_transfer_status: pass`, `transfer_byte_count: 32`, `cpu_comparison_status: pass`, `failure_stage: none`, `exit_status: 0`, and `wrapper_exit_status: 0`. Passing transfer alone does not select the final C0 runtime substrate; kernel proof and mac-focused C0 decision rerun still gate C1. Linux ROCm/HIP and TinyGPU copy-primitive side paths remain hard-blocked without their external prerequisites. DwarfStar remains reference-only.

## Phase documents

| Phase | Document | Outcome |
|---|---|---|
| C0 | `phase-c0-runtime-discovery.md`; mac-first continuation in `phase-c0a-macos-egpu-runtime-focus.md`; AMDev/SDMA unblock path in `phase-c0b-native-amdev-sdma-transfer.md`; completed VM prerequisite in `../native-r9700-gfx12-vm-pte-tlb/README.md` | C0A host-device transfer proof is Done; minimal kernel launch proof and C0 substrate decision rerun remain. No native runtime substrate is selected for C1 yet. |
| C1 | `phase-c1-native-producer-parity.md` | Dependency-blocked until C0 selects a substrate or actionable split; then a tinygrad-free producer must emit a token-exact prompt cache. |
| C2 | `phase-c2-serving-integration.md` | Dependency-blocked on C1 parity before real mlx-lm serving integration. |
| C3 | `phase-c3-native-backend-decision.md` | Dependency-blocked on C2 evidence before deciding/prototyping a direct native mlx-lm/oMLX backend. |
| Validation | `validation-commands.md` | Shared exact commands and discovery rules. |

## Sequencing dependencies

```text
Phase 0 PASS (done)
    ↓
C0 runtime discovery
    ↓
C1 native producer parity
    ↓
C2 serving integration
    ↓
C3 native backend decision/prototype
```

Bridge Phase A1/A2 (tinygrad daemon/consumer wrapper) is optional and not a prerequisite for Path C. Use it only if a working service bridge is needed before the native producer lands.

## Shared contracts and artifacts

- **KV interchange format:** `.safetensors` prompt cache compatible with mlx-lm `load_prompt_cache`; per-layer `KVCache`, empty `meta_state`, global `offset`, fp16 K/V, Llama 3.2 1B `(1, 8, N, 64)` geometry for the first parity model.
- **mlx-lm injection contract:** imported cache covers `S-1`; final prompt token is supplied to `generate_step`.
- **RoPE contract:** Llama-3 scaling comes from the MLX `config.json` sidecar when GGUF lacks `rope_scaling`.
- **Parity gate:** native baseline `R` = mlx-lm prefill/decode; producer path `P` = native R9700 prefill/export/import + mlx-lm decode; success is `P == R` across the Phase 0 prompt suite.
- **Review artifacts:** every GPU/harness run writes a local log under `logs/`; logs and model files stay uncommitted.
- **Reference corpus:** DwarfStar / `antirez/ds4` is prior art for narrow engine/kernels/testing only.

## Orchestration overview

- C0 completed source capture and proof-lane attempts, then continued through the serial macOS eGPU runtime path in `phase-c0a-macos-egpu-runtime-focus.md`; Linux ROCm/HIP remains a reference fallback rather than the initial work lane. The VM/PTE/TLB prerequisite and native SDMA host-device transfer proof are complete; the active C0A gate is now minimal kernel launch/readback.
- C1 serializes on a selected runtime substrate or actionable split plan from C0. Until the macOS C0A plan produces a passing kernel proof and C0 task set 5 reruns to a selected substrate, C1 native producer parity, runtime shells, kernel/model slices, and C1 command discovery are not actionable.
- C2 serializes on C1 parity. Wrapper, fallback, and oMLX-scope decision can proceed in parallel only after the producer invocation contract is frozen by C1.
- C3 serializes on C2 performance evidence; it must not start as implementation without a decision task and likely a new ADR if the KV interchange fast path is retired.

## Current blockers and future decisions

- C0 blocker: macOS native host-device transfer/readback now passes on the TinyGPU.app/IOKit PCI path; no minimal kernel launch/readback proof or substrate decision rerun has passed yet. The previous C0A visibility blocker was wrong because tinygrad sees the R9700 through TinyGPU.app/IOKit PCI (`APLRemotePCIDevice`, `PCIIface`, `pcibus usb4`, `arch gfx1201`), not through the stale libusb-only TinyGPU VID/PID probe.
- C1 blocker: runtime substrate selection is absent; do not start C1 task execution or command discovery until C0 is unblocked by macOS transfer/kernel evidence and task set 5 selects a substrate, or an explicitly reactivated fallback path.
- C2 oMLX scope remains a future decision after C1 parity: mlx-lm only first, or include oMLX imported-cache seam.
- C3 backend seam remains a future decision after C2 evidence: mlx-lm first, oMLX first, shared backend layer, or no direct backend.
- Post-Llama model target remains a future decision after C1 parity.
