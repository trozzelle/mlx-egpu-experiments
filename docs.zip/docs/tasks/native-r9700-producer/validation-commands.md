# Native R9700 Producer — Validation Commands

This file is the shared command ledger for `docs/tasks/native-r9700-producer/`. Agents must add exact commands here when a phase task discovers them. Do not write placeholder commands; if a command is not knowable before implementation, name the task set that must discover it.

## Fixed environment

Use this Python for Python-side validation in this repo:

```sh
/Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3
```

Do not rely on `python3` from `PATH`.

For AMD eGPU/tinygrad comparison runs that intentionally use tinygrad:

```sh
DEV=AMD
JITBEAM=2
HF_HOME=/Users/torinrozzelle/Development/ml/models
```

Path C native producer commands must not import or call tinygrad unless explicitly running a comparison/control command outside the producer path.

## Exact commands known now

### Existing Python regression suite

```sh
/Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -m pytest tests -v
```

Expected last known result from Phase 0 handoff:

```text
17 passed, 2 warnings
```

### Existing harness syntax check

```sh
/Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -m py_compile tinygrad_kv_worker/harness.py
```

Expected last known result from Phase 0 handoff: exit 0.

### Existing Phase 0 GPU parity command

This is a regression/control command for the validated tinygrad producer path, not a Path C native command:

```sh
DEV=AMD JITBEAM=2 HF_HOME=/Users/torinrozzelle/Development/ml/models \
  /Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -m tinygrad_kv_worker.harness \
  --gguf mlx_models/meta-Llama-3.2-1B-Instruct.F16.gguf \
  --mlx mlx_models/meta-Llama-3.2-1B-Instruct \
  --out docs/path-a-validation-results.md \
  --run-tag meta-f16-final
```

Expected last known result from Phase 0 handoff:

```text
Gate PASS; report written to docs/path-a-validation-results.md
```

### C0A macOS TinyGPU.app / IOKit PCI discovery probe

This is the correct macOS visibility check for the existing tinygrad R9700 path. It is a reference/discovery command, not a Path C native producer command: it imports tinygrad to prove the substrate used by the working Phase 0 path.

```sh
JITBEAM=2 DEV=AMD PYTHONPATH=/Users/torinrozzelle/Development/ml/tools/tinygrad \
  /Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -c "from tinygrad.runtime.support.system import System; from tinygrad import Device; devs=System.list_devices(0x1002, ((0xffff,(0x74a1,0x744c,0x7480,0x7550,0x7551,0x7590,0x75a0)),), None); print('amd_pci_devices', devs); d=Device['AMD']; print('iface', type(d.iface).__name__); print('arch', d.arch); print('pcibus', getattr(d.iface.pci_dev, 'pcibus', None)); print('pci_dev_class', type(d.iface.pci_dev).__name__)"
```

Observed supervisor result:

```text
amd_pci_devices [(<class 'tinygrad.runtime.support.system.APLRemotePCIDevice'>, '1002:7551')]
iface PCIIface
arch gfx1201
pcibus usb4
pci_dev_class APLRemotePCIDevice
```

User-provided working model/server command for the same substrate:

```sh
JITBEAM=2 DEV=AMD python3 -m tinygrad.llm
```

Task set 2 pinned the client-side native contract from the TinyGPU.app/APLRemotePCIDevice/PCIIface path, not from the stale libusb-only `USBIface` probe below.
Task set 3 is now satisfied by the C0B native AMDev/SDMA transfer proof below. The visible TinyGPU.app client ABI exposes primitive `RemoteCmd` PCI/sysmem/BAR/MMIO operations, so the passing proof implements the necessary tinygrad-free native AMD bring-up locally: BAR0/BAR2/BAR5 mapping, IP discovery, fixed gfx12 page tables, MMHUB VMID0/TLB setup, source-grounded SDMA0 7.0.1 queue0 reset/programming, BAR2 doorbell submission, fence polling, and CPU byte comparison. The latest supervisor log is `logs/c0b-native-amdev-sdma-transfer.log` at `2026-08-17T13:31:58Z` with all host-device transfer pass tokens.

### C0A task set 3 host-device transfer proof evidence

The TinyGPU.app/APLRemotePCIDevice/PCIIface host↔device transfer command is the C0B native AMDev/SDMA transfer proof command in this file. It is accepted for C0A task set 3 only when the log contains:

- `runtime_substrate: TinyGPU.app/APLRemotePCIDevice/PCIIface`
- `pci_id: 1002:7551`
- `arch: gfx1201`
- `transfer_byte_count: 32`
- `cpu_comparison_status: pass`
- `host_device_transfer_status: pass`
- `failure_stage: none`
- `exit_status: 0`
- `wrapper_exit_status: 0`

The stale libusb-only command below remains a negative control and must not be used for transfer acceptance.

### C0B native AMDev/SDMA transfer contract tests

This is the no-hardware RED/GREEN contract for `experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp`. Task set 1 expects RED before production source exists; task set 2 and later must make it green without importing tinygrad or using libusb as the acceptance path.

```sh
/Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -m pytest tests/test_native_amdev_transfer_contract.py -v
```

Expected RED result before C0B task set 2:

```text
AssertionError: native transfer probe source missing
```

### C0B TinyGPU.app discovery smoke

This is the hardware discovery smoke for task set 3. It builds the native probe, runs `--discovery-smoke`, and writes `logs/c0b-discovery-smoke.log`.

```sh
/bin/bash -o pipefail -c 'mkdir -p build/native-r9700-runtime logs; log=logs/c0b-discovery-smoke.log; { printf "%s\n" "command: xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --discovery-smoke"; date -u "+timestamp_utc: %Y-%m-%dT%H:%M:%SZ"; xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --discovery-smoke; status=$?; printf "wrapper_exit_status: %d\n" "$status"; exit "$status"; } 2>&1 | tee "$log"'
```

OMP task executors record this command for the supervisor; they do not run it in task mode.

### C0B native AMDev/SDMA transfer proof

This is the task set 5 hardware transfer proof command. It builds the tinygrad-free native probe, runs `--transfer-proof`, and writes `logs/c0b-native-amdev-sdma-transfer.log`. Success requires `host_device_transfer_status: pass`, `transfer_byte_count: 32`, `cpu_comparison_status: pass`, and both `exit_status: 0` and `wrapper_exit_status: 0`. A precise blocker is acceptable only with nonzero exit and `failure_stage: vm_mapping`, `sdma_ring_setup`, `sdma_submit`, `timeline_timeout`, or `readback_mismatch`.

```sh
/bin/bash -o pipefail -c 'mkdir -p build/native-r9700-runtime logs; log=logs/c0b-native-amdev-sdma-transfer.log; { printf "%s\n" "command: xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --transfer-proof"; date -u "+timestamp_utc: %Y-%m-%dT%H:%M:%SZ"; xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --transfer-proof; status=$?; printf "wrapper_exit_status: %d\n" "$status"; exit "$status"; } 2>&1 | tee "$log"'
```

OMP task executors record this command for the supervisor; they do not run it in task mode.

### C0A task set 4 native AMDev kernel proof / precise blocker

This is the C0A task set 4 supervisor hardware command. It builds the tinygrad-free native probe, runs `--kernel-proof`, and writes `logs/c0-macos-egpu-minimal-runtime.log`. A future pass requires `kernel_launch_status: pass`, `kernel_elapsed_usec`, `cpu_comparison_status: pass`, `host_device_transfer_status: pass`, `failure_stage: none`, `exit_status: 0`, and `wrapper_exit_status: 0` after CPU readback equals expected `2,3,4,5,6,7,8,9`. The current reviewed outcome is a nonzero precise blocker with `failure_stage: compute_ring_setup` after the TinyGPU.app/APLRemotePCIDevice/PCIIface discovery, VM, and SDMA substrate are logged.

```sh
/bin/bash -o pipefail -c 'mkdir -p build/native-r9700-runtime logs; log=logs/c0-macos-egpu-minimal-runtime.log; { printf "%s\n" "command: xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --kernel-proof"; date -u "+timestamp_utc: %Y-%m-%dT%H:%M:%SZ"; xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra experiments/native-r9700-runtime/native_amdev_transfer_probe.cpp -o build/native-r9700-runtime/native_amdev_transfer_probe && build/native-r9700-runtime/native_amdev_transfer_probe --kernel-proof; status=$?; printf "wrapper_exit_status: %d\n" "$status"; exit "$status"; } 2>&1 | tee "$log"'
```

OMP task executors record this command for the supervisor; they do not run it in task mode.


### C0B gfx12 VM/PTE/TLB prerequisite

This split-out implementation plan and task-doc set completed the previous `failure_stage: vm_mapping` blocker. The SDMA follow-up completed the transfer command above; the latest hardware log records `failure_stage: none` and host-device transfer pass evidence.

```sh
/Users/torinrozzelle/.pyenv/versions/3.12.8/bin/python3 -m pytest tests/test_native_amdev_transfer_contract.py -v
```

After SDMA ring setup/submission is implemented, supervisor reruns the C0B native AMDev/SDMA transfer proof command above and accepts only a real transfer pass or a later precise nonzero blocker.

### C0 macOS stale libusb-only probe

This negative-control command targets tinygrad's separate `USBIface` path (`USB3.list_devices(0xADD1, 0x0001)`) and does not represent the working local R9700 path. The working path above is TinyGPU.app/IOKit PCI through `APLRemotePCIDevice` and `PCIIface`.

Run from the repo root only when intentionally checking the stale libusb-only assumption against `experiments/native-r9700-runtime/macos_tinygpu_minimal.cpp`:

```sh
/bin/bash -o pipefail -c 'mkdir -p build/native-r9700-runtime logs; log=logs/c0-macos-egpu-minimal-runtime.log; { printf "%s\n" "command: xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra -I/opt/homebrew/include/libusb-1.0 experiments/native-r9700-runtime/macos_tinygpu_minimal.cpp -L/opt/homebrew/lib -Wl,-rpath,/opt/homebrew/lib -lusb-1.0 -o build/native-r9700-runtime/macos_tinygpu_minimal && ./build/native-r9700-runtime/macos_tinygpu_minimal"; date -u +"timestamp_utc: %Y-%m-%dT%H:%M:%SZ"; xcrun --sdk macosx clang++ -std=c++17 -O2 -Wall -Wextra -I/opt/homebrew/include/libusb-1.0 experiments/native-r9700-runtime/macos_tinygpu_minimal.cpp -L/opt/homebrew/lib -Wl,-rpath,/opt/homebrew/lib -lusb-1.0 -o build/native-r9700-runtime/macos_tinygpu_minimal && ./build/native-r9700-runtime/macos_tinygpu_minimal; status=$?; printf "exit_status: %d\n" "$status"; exit "$status"; } 2>&1 | tee "$log"'
```

This command shape is concrete on the local macOS toolchain: `xcrun --find clang++` resolves to `/Library/Developer/CommandLineTools/usr/bin/clang++`, `/opt/homebrew/include/libusb-1.0/libusb.h` exists, and `/opt/homebrew/lib/libusb-1.0.dylib` exists. It is a negative control only. It must not be used for C0A host↔device transfer acceptance because it targets `USB3.list_devices(0xADD1, 0x0001)`/`USBIface`, not TinyGPU.app/APLRemotePCIDevice/PCIIface.

### C0 Linux ROCm/HIP reference probe

Immediate execution is blocked in this macOS worktree because no Linux ROCm/HIP host is attached to this task and `hipcc` is not installed here (`which hipcc` exits 1). Task set 3 owns provisioning a ROCm-capable AMD Linux host or recording the remote-access blocker. Once that host has the repo worktree and HIP SDK, run this exact reference command from the repo root after task set 3 adds `experiments/native-r9700-runtime/linux_hip_minimal.cpp`:

```sh
/bin/bash -o pipefail -c 'mkdir -p build/native-r9700-runtime logs; log=logs/c0-linux-hip-minimal-runtime.log; { printf "%s\n" "command: hipcc -std=c++17 -O2 experiments/native-r9700-runtime/linux_hip_minimal.cpp -o build/native-r9700-runtime/linux_hip_minimal && ./build/native-r9700-runtime/linux_hip_minimal"; date -u +"timestamp_utc: %Y-%m-%dT%H:%M:%SZ"; hipcc --version; if command -v rocminfo >/dev/null 2>&1; then rocminfo; fi; hipcc -std=c++17 -O2 experiments/native-r9700-runtime/linux_hip_minimal.cpp -o build/native-r9700-runtime/linux_hip_minimal && ./build/native-r9700-runtime/linux_hip_minimal; status=$?; printf "exit_status: %d\n" "$status"; exit "$status"; } 2>&1 | tee "$log"'
```

The probe executable must print HIP device identity/architecture, CPU comparison, host↔device transfer result, kernel timing, and any HIP error text into the captured log.

### C0 handoff documentation check

Supervisor verification command for final C0 handoff documentation:

```sh
git diff --check docs/tasks/native-r9700-producer/README.md docs/tasks/native-r9700-producer/phase-c0-runtime-discovery.md docs/tasks/native-r9700-producer/validation-commands.md
```

OMP task executors record this command for the supervisor; they do not run it in task mode.

### Documentation whitespace check

Use this after task-doc or design-doc edits:

```sh
git diff --check
```

## Commands that must be discovered before execution

| Phase | Command | Owning task set | Status |
|---|---|---|---|
| C0 | macOS eGPU minimal runtime build/run/log command | `phase-c0-runtime-discovery.md` task set 1; continued by `phase-c0a-macos-egpu-runtime-focus.md` task sets 1-4 | Visibility discovery path is TinyGPU.app/IOKit PCI via `APLRemotePCIDevice`/`PCIIface`, with observed `arch gfx1201`; task set 3 transfer proof passes through the C0B native AMDev/SDMA command; task set 4 kernel proof command is recorded above for `logs/c0-macos-egpu-minimal-runtime.log` with expected `failure_stage: compute_ring_setup` until native GC/MEC/HQD compute ring setup is safely ported; stale libusb-only probe is retained as a negative control |
| C0B | native AMDev/SDMA transfer proof build/run/log command | `phase-c0b-native-amdev-sdma-transfer.md` task set 5 | Exact build/run/log command recorded above for `logs/c0b-native-amdev-sdma-transfer.log`; current native probe has reviewed VM/PTE/TLB pass evidence and SDMA0 7.0.1 queue0 pass evidence with `host_device_transfer_status: pass`, `cpu_comparison_status: pass`, `failure_stage: none`, `exit_status: 0`, and `wrapper_exit_status: 0` |
| C0 | Linux ROCm/HIP reference build/run/log command | `phase-c0-runtime-discovery.md` task set 1 | Reference fallback; immediate local execution remains blocked pending ROCm Linux host/HIP SDK; provisioned-host command recorded above |
| C1 | native loader/config validation command | `phase-c1-native-producer-parity.md` task set 1 or 2 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | reference-fixture generation command | `phase-c1-native-producer-parity.md` task set 1 or 3 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | native runtime shell validation command | `phase-c1-native-producer-parity.md` task set 1 or 4 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | primitive kernel test commands | `phase-c1-native-producer-parity.md` task set 5 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | attention/RoPE/KV writer test command | `phase-c1-native-producer-parity.md` task set 6 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | full-stack native prefill smoke command | `phase-c1-native-producer-parity.md` task set 7 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | native KV emitter/load round-trip command | `phase-c1-native-producer-parity.md` task set 8 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C1 | native producer parity command | `phase-c1-native-producer-parity.md` task set 9 | Blocked by C0 substrate selection; do not discover until C0 has a passing substrate or actionable split |
| C2 | mlx-lm wrapper focused test command | `phase-c2-serving-integration.md` task set 1 or 2 | Dependency-blocked by C1 parity; not discovered |
| C2 | fallback/error-state test command | `phase-c2-serving-integration.md` task set 1 or 3 | Dependency-blocked by C1 parity; not discovered |
| C2 | serving integration command | `phase-c2-serving-integration.md` task set 4 | Dependency-blocked by C1 parity; not discovered |
| C2 | oMLX integration command, if in scope | `phase-c2-serving-integration.md` task set 5 or 6 | Dependency-blocked by C1 parity and later scope decision; not discovered |
| C3 | backend prototype command, if approved | `phase-c3-native-backend-decision.md` task set 2 or 4 | Dependency-blocked by C2 evidence and backend decision; not discovered |
| C3 | backend comparison command, if approved | `phase-c3-native-backend-decision.md` task set 5 | Dependency-blocked by C2 evidence and backend decision; not discovered |

## Log requirements for all GPU/native runs

Every GPU/native run must write a reviewable local log under `logs/` or record an explicit remote log artifact path. Logs must include:

- command line;
- timestamp;
- runtime substrate and device identity if discoverable;
- model/config path or note that no model is used;
- prompt length or input shape;
- output comparison result or digest;
- exit status;
- failure traceback/error text when failing.

Logs and model files must not be committed.

## Gate reminders

- Producer-swap acceptance is token-exact `P == R`, not semantic equivalence.
- mlx-lm injected decode uses an imported `S-1` prefix cache plus the final prompt token.
- Llama-3 RoPE scaling must match the MLX sidecar config.
- Path C native producer code must not depend on tinygrad.
- C1 native producer commands remain blocked until C0 records a selected runtime substrate or actionable split production/reference plan. Current C0 task set 5 state is blocked. User steering selects macOS eGPU runtime as the initial unblock focus via `phase-c0a-macos-egpu-runtime-focus.md`; do not discover or run C1 native runtime/kernel commands until the macOS proof, or an explicitly reactivated fallback proof, clears the C0 blocker.
